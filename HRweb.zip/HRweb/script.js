function validateForm() {
    var fullName = document.getElementById("fullName").value;
    var email = document.getElementById("email").value;
    var address = document.getElementById("address").value;
    var phone = document.getElementById("phone").value;
    var position = document.getElementById("position").value;
    var department = document.getElementById("department").value;
    var salary = document.getElementById("salary").value;
    var hireDate = document.getElementById("hireDate").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    // Validation for empty fields
    if (fullName.trim() === "" || email.trim() === "" || address.trim() === "" || 
        phone.trim() === "" || position.trim() === "" || department.trim() === "" || 
        salary.trim() === "" || hireDate.trim() === "" || password.trim() === "" || 
        confirmPassword.trim() === "") {
        alert("Please fill in all fields");
        return false;
    }

    // Email validation
    var emailRegex = /^\S+@\S+\.\S+$/;
    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address");
        return false;
    }

    // Password match validation
    if (password !== confirmPassword) {
        alert("Passwords do not match");
        return false;
    }

    // Validation for salary
    if (isNaN(salary)) {
        alert("Salary must be a number");
        return false;
    }

    // Validation for phone number
    var phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phone)) {
        alert("Please enter a valid 10-digit phone number");
        return false;
    }

    return true;
}
